﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta />
    <title>Change password</title>
    <!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/StyleSheet2.css" rel="stylesheet">

</head>
<body>
    <h1><marquee>Welcome to the change password page</marquee></h1>
    <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <hr />
    <div class="offset-xl-3 col-xl-5">
        <nav class="navbar navbar-expand-sm navbar-light bg-light">
            <a style="color: red;" class="navbar-text" href="StudentHomePage.php">Student Homepage</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="Feedback.php">Feedback</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="Home.php">Logout</a>
        </nav>
    </div>
    <br />

<?php
session_start();
$user = $_SESSION["user"];

echo "User ID: ".$user;
?>

    <br />
    <div class="container">
        <form name="" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <h2>Change password</h2>
                </div>
            </div>

            <div class="form-group row">
                <label for="password" class="control-label col-xl-3">Old password: </label>
                <div class="col-xl-6">
                    <input type="password" class="form-control" id="password" name="Password" />
                </div>
            </div>

            <div class="form-group row">
                <label for="newpassword" class="control-label col-xl-3">New password: </label>
                <div class="col-xl-6">
                    <input type="password" class="form-control" id="newpassword" name="NewPassword" />
                </div>
            </div>

            <div class="form-group row">
                <label for="retypepassword" class="control-label col-xl-3">Retyped password: </label>
                <div class="col-xl-6">
                    <input type="password" class="form-control" id="retypepassword" name="RetypePassword" />
                </div>
            </div>

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <input type="submit" class="btn btn-secondary" value="Submit" />
                </div>
            </div>

<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "ViewProfile2");

if (!$conn)
{
    die("Connection failed: ".mysqli_connection_error());
}

$password = htmlspecialchars(stripslashes($_POST["Password"]));
$newpassword = htmlspecialchars(stripslashes($_POST["NewPassword"]));
$retypepassword = htmlspecialchars(stripslashes($_POST["RetypePassword"]));

$select = "select StudentID from Students where StudentID = '$user' and StudentPassword = password('$password')";
$res = mysqli_query($conn, $select);

if (mysqli_num_rows($res)>0)
{
    if (strlen($newpassword) >=8 && $newpassword == $retypepassword)
    {
        $update = "update Students set StudentPassword = password('$newpassword') where StudentID = '$user'";
        $r = mysqli_query($conn, $update);

        if ($r)
        {
            echo "Changed";
        }
        else
        {
            echo "Error updating: ".mysqli_error($conn);
        }
    }
    else
    {
        echo "The new password is not in a right format or it does not match the re-typed password";
    }
}
else
{
    echo "The old password is wrong or is empty";
}

mysqli_close($conn);
?>

        </form>
    </div>

    <br />
    <footer class="offset-xl-3"><marquee>&copy</marquee></footer>
</body>
</html>
