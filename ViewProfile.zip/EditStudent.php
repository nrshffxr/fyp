﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta />
    <title>Edit student</title>
    <!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/StyleSheet2.css" rel="stylesheet">
    <link href="lib/dtpicker/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link href="lib/font-awesome/css/fontawesome.min.css" rel="stylesheet" />
    <link href="lib/font-awesome/css/brands.min.css" rel="stylesheet" />
    <link href="lib/font-awesome/css/solid.min.css" rel="stylesheet" />


</head>
<body>
    <h1><marquee>Welcome to the edit student page</marquee></h1>
    <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="lib/moment/moment.min.js"></script>
    <script src="lib/dtpicker/js/tempusdominus-bootstrap-4.min.js"></script>
    <script language="javascript">
        $(document).ready(function () {
            $('#StudentsBirthdateEdit').datetimepicker({ format: 'YYYY-MM-DD' });
        });
    </script>
    <hr />
    <div class="offset-xl-0 col-xl-12">
        <nav class="navbar navbar-expand-sm navbar-light bg-light">
            <a style="color: red;" class="navbar-text" href="AdministratorHomePage.php">Administrator Homepage</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ListStudentsAccount.php">List students' account</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ListAdministratorsAccount.php">List administrators' account</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ViewFeedback.php">View feedbacks</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="CreateStudent.php">Create student</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="DeleteUser.php">Delete user</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="CreateAdministrator.php">Create administrator</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="EditAdministrator.php">Edit administrator</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="Lock.php">Lock</a>
            <a style="color: red;" class="navbar-text" href="Home.php">Logout</a>
        </nav>
    </div>
    <br />

<?php
session_start();
$user = $_SESSION["name"];

echo "User ID: ".$user;
?>

    <br />
    <div class="container">
        <form name="" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <h2>Edit student account</h2>
                </div>
            </div>

            <div class="form-group row">
                <label for="studentID" class="control-label col-xl-3">Student ID: </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="studentID" name="StudentID" />
                </div>
            </div>

            <div class="form-group row">
                <label for="studentName" class="control-label col-xl-3">Student name: </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="studentName" name="StudentName" />
                </div>
            </div>

            <div class="form-group row">
                <label for="studentPassword" class="control-label col-xl-3">Student password: </label>
                <div class="col-xl-6">
                    <input type="password" class="form-control" id="studentPassword" name="StudentPassword" />
                </div>
            </div>

            <!--<div class="form-group row">
                <label for="isItLocked" class="control-label col-xl-3">Is it locked (Y/N?): </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="isItLocked" name="IsItLocked" />
                </div>
            </div>-->

            <div class="form-group row">
                <label for="studentEmail" class="control-label col-xl-3">Student E-mail: </label>
                <div class="col-xl-6">
                    <input type="email" class="form-control" id="studentEmail" name="StudentEmail" />
                </div>
            </div>

            <!--<div class="form-group row">
                <label for="studentBirthdate" class="control-label col-xl-3">Student date of birth (YYYY-MM-DD) / (YYYY-M-D): </label>
                <div class="col-xl-6">
                    <div class="input-group date" id="StudentsBirthdateEdit" data-target-input="nearest">
                        <input type="text" class="form-control" id="studentBirthdate" name="StudentBirthdate" />
                        <div class="input-group-append" data-target="#StudentsBirthdateEdit" data-toggle="datetimepicker">
                            <div class="input-group-text">
                                <i class="fas fa-calendar"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>-->

            <div class="form-group row">
                <label for="birthYear" class="control-label col-xl-3">Student birthdate (YYYY): </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="birthYear" name="Year" />
                </div>
            </div>

            <div class="form-group row">
                <label for="birthMonth" class="control-label col-xl-3">Student birthdate (MM/M): </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="birthMonth" name="Month" />
                </div>
            </div>

            <div class="form-group row">
                <label for="birthDay" class="control-label col-xl-3">Student birthdate (DD/D): </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="birthDay" name="Day" />
                </div>
            </div>

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <input type="submit" class="btn btn-secondary" value="Submit" />
                </div>
            </div>

<?php
$conn = mysqli_connect("localhost", "root", "", "ViewProfile2");

if (!$conn)
{
    die("Connection failed: ".mysqli_connect_error());
}

$id = htmlspecialchars(stripslashes(trim($_POST["StudentID"])));
$name = htmlspecialchars(stripslashes(trim($_POST["StudentName"])));
$password = htmlspecialchars(stripslashes($_POST["StudentPassword"]));
$email = htmlspecialchars(stripslashes(trim($_POST["StudentEmail"])));
$year = htmlspecialchars(stripslashes(trim($_POST["Year"])));
$month = htmlspecialchars(stripslashes(trim($_POST["Month"])));
$day = htmlspecialchars(stripslashes(trim($_POST["Day"])));

$select = "select * from Students where StudentID = '$id'";
$r = mysqli_query($conn, $select);

if (mysqli_num_rows($r)>0)
{
    if ((int)$name != 0)
    {
        echo "Name's format is wrong and it must not be blank";
    }
    else
    {
        if (strlen($password)>=8)
        {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL))
            {
                echo "The E-mail's format is wrong or that field is empty";
            }
            else
            {
                if (empty($year) && empty($month) && empty($day))
                {
                    echo "The year, month and day must not be empty";
                }
                else
                {
                    if (strlen($year) == 4 && (int)$year == $year && (int)$year >= 0 && (int)$year <= 9999 && (int)$month >= 1 && (int)$month <= 12 && (int)$month == $month && (strlen($month) >= 1 && strlen($month) <= 2) && 
(
((int)$day >= 1 && (int)$day <= 28) || 
((int)$day >= 1 && (int)$day <= 29) || 
((int)$day >= 1 && (int)$day <= 30) || 
((int)$day >= 1 && (int)$day <= 31)
)
 && (int)$day == $day && 
(strlen($day) >= 1 && strlen($day) <= 2))
                    {
                        $date = $year."-".$month."-".$day;
                                $update = "update Students set StudentName = '$name', StudentPassword = password('$password'), StudentEmail = '$email', StudentDateOfBirth = '$date' where StudentID = '$id'";
                        $res = mysqli_query($conn, $update);

                        if ($res)
                        {
                            echo "Updated successfully";
                        }
                        else
                        {
                            echo "Error updating: ".mysqli_error($conn);
                        }
                    }
                    else
                    {
                        echo "The birthdate's format is wrong";
                    }
                }
            }
        }
        else
        {
            echo "The password's format is wrong";
        }
    }
}
else
{
    echo "There is no such user with that student ID or that field is blank";
}

mysqli_close($conn);
?>

        </form>
    </div>
    <br />
    <footer class="offset-xl-3"><marquee>&copy</marquee></footer>
</body>
</html>
