﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta />
    <title>Feedback</title>
    <!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/StyleSheet2.css" rel="stylesheet">


</head>
<body>
    <h1><marquee>Welcome to the feedback page</marquee></h1>
    <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <hr />
    <div class="offset-xl-3 col-xl-5">
        <nav class="navbar navbar-expand-sm navbar-light bg-light">
            <a style="color: red;" class="navbar-text" href="StudentHomePage.php">Student Homepage</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ChangePassword.php">Change password</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="Home.php">Logout</a>
        </nav>
    </div>
    <br />

<?php
session_start();
$user = $_SESSION["user"];

echo "User ID: ".$user;
?>

    <br />
    <div class="container">
        <form name="" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <h2>Feedback</h2>
                </div>
            </div>

            <div class="form-group row">
                <label for="feedBack" class="control-label col-xl-3">Feedback: </label>
                <div class="col-xl-6">
                    <textarea class="form-control" id="feedBack" name="FeedBack" cols="35" rows="4"></textarea>
                </div>
            </div>

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <input type="submit" class="btn btn-secondary" value="Submit" />
                </div>
            </div>

<?php
$conn = mysqli_connect("localhost", "root", "", "ViewProfile2");

if (!$conn)
{
    die("Connection failed: ".mysqli_connect_error());
}

$feedback = htmlspecialchars(stripslashes($_POST["FeedBack"]));

if (empty($feedback))
{
    echo "Please enter something";
}
else
{
    $CurrentDateAndTime = date("Y/m/d H:i:s");
    $insert = "insert into Feedbacks (Feedback, Timestamp) values ('$feedback', '$CurrentDateAndTime')";
    $r = mysqli_query($conn, $insert);

    if ($r)
    {
        echo "Feedbacked successfully";
    }
    else
    {
        echo "Error: ".$insert."<br>".mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

        </form>
    </div>
    <br />
    <footer class="offset-xl-3"><marquee>&copy</marquee></footer>
</body>
</html>
