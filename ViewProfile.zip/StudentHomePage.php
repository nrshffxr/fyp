﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta />
    <title>Student homepage</title>
    <!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/StyleSheet2.css" rel="stylesheet">

</head>
<body>
    <h1><marquee>Welcome to the student home page</marquee></h1>
    <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <hr />
    <div class="offset-xl-3 col-xl-5">
        <nav class="navbar navbar-expand-sm navbar-light bg-light">
            <a style="color: red;" class="navbar-text" href="Feedback.php">Feedback</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ChangePassword.php">Change password</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="Home.php">Logout</a>
        </nav>
    </div>
    <br />
<?php
session_start();
$user = $_SESSION["user"];

echo "User ID: ".$user;
?>
    <br />
    <footer class="offset-xl-3"><marquee>&copy</marquee></footer>
</body>
</html>
