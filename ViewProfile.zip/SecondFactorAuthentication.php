﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta />
    <title>Second factor authentication</title>
    <!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/StyleSheet2.css" rel="stylesheet">


</head>
<body>
    <h1><marquee>Welcome to the 2<sup>nd</sup> factor authentication page</marquee></h1>
    <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>

    <hr />
    <div class="offset-xl-3 col-xl-5">
        <nav class="navbar navbar-expand-sm navbar-light bg-light"><a style="color: red;" class="navbar-text" href="Home.php">Home</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="StudentLogin.php">Students Login</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="AdministratorLogin.php">Administrators Login</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="AboutUs.php">About Us</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="">Contact Us</a>
        </nav>
    </div>
    <br />

    <div class="container">
        <form name="" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <h2>Second factor authentication</h2>
                </div>
            </div>

            <div class="form-group row">
                <label for="secondFactor" class="control-label col-xl-3">Second factor: </label>
                <div class="col-xl-6">
                    <input type="password" class="form-control" id="secondFactor" name="SecondFactor" />

<?php
session_start();
$servername = "localhost";
$user = "root";
$pass = "";
$dbname = "ViewProfile2";

$conn = mysqli_connect("localhost", "root", "", "ViewProfile2");

if (!$conn)
{
    die("Connection failed: ".mysqli_connect_error());
}
else
{
}

$name = $_SESSION["name"];
$sec = htmlspecialchars(stripslashes(trim($_POST["SecondFactor"])));
$otp = rand(0,9999);
$insert = "Update Administrators set SecondFactor = password('$otp') where AdministratorID = '$name'";
$sql = "select AdministratorID from Administrators where AdministratorID = '$name' and SecondFactor = password('$sec')";

if (empty($sec))
{
    echo "The field is required.";
    
    $result = mysqli_query($conn, $insert);
    
    if ($result)
    {
        echo "<script>alert('The OTP is $otp.')</script>";
    }
}
else
{
    $data = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($data)>0)
    {
        header("location: AdministratorHomePage.php");
    }
    else
    {
        echo "The second factor is wrong.";
    }
}
mysqli_close($conn);
?>

                </div>
            </div>

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <input type="submit" class="btn btn-secondary" value="Submit" />
                </div>
            </div>

        </form>
    </div>
    <br />
    <footer class="offset-xl-3"><marquee>&copy</marquee></footer>
</body>
</html>
