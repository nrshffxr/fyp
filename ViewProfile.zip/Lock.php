﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta />
    <title>Lock or unlock accounts page</title>
    <!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/StyleSheet2.css" rel="stylesheet">

</head>
<body>
    <h1><marquee>Welcome to the lock or unlock accounts page</marquee></h1>
    <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <hr />
    <div class="offset-xl-0 col-xl-12">
        <nav class="navbar navbar-expand-sm navbar-light bg-light">
            <a style="color: red;" class="navbar-text" href="AdministratorHomePage.php">Administrator Homepage</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ListStudentsAccount.php">List students' account</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ListAdministratorsAccount.php">List administrators' account</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ViewFeedback.php">View feedbacks</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="CreateStudent.php">Create student</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="EditStudent.php">Edit student</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="DeleteUser.php">Delete user</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="CreateAdministrator.php">Create administrator</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="EditAdministrator.php">Edit administrator</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="Home.php">Logout</a>
        </nav>
    </div>
    <br />

<?php
session_start();
$user = $_SESSION["name"];

echo "User ID: ".$user;
?>

    <br />
    <div class="container">
        <form name="" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <h2>Lock accounts or unlock accounts</h2>
                </div>
            </div>

            <div class="form-group row">
                <label for="studentOrAdministratorID" class="control-label col-xl-3">Student or administrator ID: </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="studentOrAdministratorID" name="StudentOrAdministratorID" />
                </div>
            </div>

            <div class="form-group row">
                <label for="lock" class="control-label col-xl-3">Do you want to lock? (Y/N/y/n): </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="lock" name="Lock" />
                </div>
            </div>

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <input type="submit" class="btn btn-secondary" value="Submit" />
                </div>
            </div>

<?php
$conn = mysqli_connect("localhost", "root", "", "ViewProfile2");

if (!$conn)
{
    die("Connection failed: ".mysqli_connect_error());
}

$ID = htmlspecialchars(stripslashes(trim($_POST["StudentOrAdministratorID"])));
$lock = htmlspecialchars(stripslashes(trim($_POST["Lock"])));

$select = "select StudentID from Students where StudentID = '$ID'";
$r = mysqli_query($conn, $select);

if (mysqli_num_rows($r)>0)
{
    $update = "Update Students set IsItLocked = '$lock' where StudentID = '$ID'";
    

    if ($lock == "Y" || $lock == "y")
    {
        $select2 = "Select StudentID from Students where StudentID = '$ID' and IsItLocked = 'N'";
        $find = mysqli_query($conn, $select2);

        if (mysqli_num_rows($find)>0)
        {
            $result = mysqli_query($conn, $update);
            if ($result)
            {
                echo "Locked successfully";
            }
            else
            {
                echo "Error locking: ".mysqli_error($conn);
            }
        }
        else
        {
            echo "The account is already locked";
        }
    }
    elseif ($lock == "N" || $lock == "n")
    {
        $find2 = "Select StudentID from Students where StudentID = '$ID' and IsItLocked = 'Y'";
        $find3 = mysqli_query($conn, $find2);

        if (mysqli_num_rows($find3)>0)
        {
            $r3 = mysqli_query($conn, $update);
            if ($r3)
            {
                echo "Unocked successfully";
            }
            else
            {
                echo "Error unlocking: ".mysqli_error($conn);
            }
        }
        else
        {
            echo "The account is already unlocked";
        }
    }
    else
    {
        echo "Please enter 'Y', 'y', 'N' or 'n'";
    }
}
else
{
    $select2 = "select * from Administrators where AdministratorID = '$ID'";
    $r2 = mysqli_query($conn, $select2);

    if (mysqli_num_rows($r2)>0)
    {
        $update2 = "update Administrators set IsItLocked = '$lock' where AdministratorID = '$ID'";
        

        if ($lock == "Y" || $lock == "y")
        {
            $find4 = "select AdministratorID from Administrators where AdministratorID = '$ID' and IsItLocked = 'N'";
            $find5 = mysqli_query($conn, $find4);

            if (mysqli_num_rows($find5)>0)
            {
                $res = mysqli_query($conn, $update2);
                if ($res)
                {
                    echo "Locked successfully";
                }
                else
                {
                    echo "Error locking: ".mysqli_error($conn);
                }
            }
            else
            {
                echo "The account is already locked";
            }
        }
        elseif ($lock == "N" || $lock == "n")
        {
            $find6 = "select AdministratorID from Administrators where AdministratorID = '$ID' and IsItLocked = 'Y'";
            $find7 = mysqli_query($conn, $find6);

            if (mysqli_num_rows($find7)>0)
            {
                $r3 = mysqli_query($conn, $update2);
        
                if ($r3)
                {
                    echo "Unlocked successfully";
                }
                else
                {
                    echo "Error unlocking: ".mysqli_error($conn);
                }
            }
            else
            {
                echo "The account is already unlocked";
            }
        }
        else
        {
            echo "Please enter a 'Y', 'y', 'N' or 'n'";
        }    
    }
    else
    {
        echo "Please enter an ID that is not non-existent";
    }
}
mysqli_close($conn);
?>

        </form>
    </div>

    <br />
    <footer class="offset-xl-3"><marquee>&copy</marquee></footer>
</body>
</html>
