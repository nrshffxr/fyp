﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta />
    <title>List administrators' account</title>
    <!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/StyleSheet2.css" rel="stylesheet">

</head>
<body>
    <h1><marquee>Welcome to the list administrators' account page</marquee></h1>
    <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <hr />
    <div class="offset-xl-0 col-xl-12">
        <nav class="navbar navbar-expand-sm navbar-light bg-light">
            <a style="color: red;" class="navbar-text" href="AdministratorHomePage.php">Administrator Homepage</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ListStudentsAccount.php">List students' account</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ViewFeedback.php">View feedbacks</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="CreateStudent.php">Create student</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="EditStudent.php">Edit student</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="DeleteUser.php">Delete user</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="CreateAdministrator.php">Create administrator</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="EditAdministrator.php">Edit administrator</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="Lock.php">Lock</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="Home.php">Logout</a>
        </nav>
    </div>
    <br />

<?php
session_start();
$user = $_SESSION["name"];

echo "User ID: ".$user;
?>

    <br />

<?php
$conn = mysqli_connect("localhost", "root", "", "ViewProfile2");

if (!$conn)
{
    die("Connection failed: ".mysqli_connect_error());
}

$select = "select * from Administrators";
$res = mysqli_query($conn, $select);

if (mysqli_num_rows($res)>0)
{
    echo "<table class='table-bordered' style ='background-color: lightblue;'> <tr> <th>Administrator ID</th> <th>NRIC</th> <th>Name</th> <th>Password</th> <th>Email</th> <th>Is it locked?</th> <th>DOB</th> </tr>";
    while ($r = mysqli_fetch_assoc($res))
    {
        echo "<tr><td>" . $r["AdministratorID"] . "</td><td>" . $r["AdministratorNRIC"] . "</td><td>" . $r["AdministratorName"] . "</td><td>" . $r["AdministratorPassword"]. "</td><td>" . $r["AdministratorEmail"] . "</td><td>" . $r["IsItLocked"] . "</td><td>" . $r["AdministratorDateOfBirth"] . "</td></tr>";
    }
    echo "</table>";
}
else
{
    echo "There are no administrator accounts in this list";
}

mysqli_close($conn);
?>

    <br />    
    <footer class="offset-xl-3"><marquee>&copy</marquee></footer>
</body>
</html>
