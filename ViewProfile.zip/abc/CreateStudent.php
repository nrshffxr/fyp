﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta />
    <title>Create student</title>
    <!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/StyleSheet2.css" rel="stylesheet">
    <link href="lib/dtpicker/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link href="lib/font-awesome/css/fontawesome.min.css" rel="stylesheet" />
    <link href="lib/font-awesome/css/brands.min.css" rel="stylesheet" />
    <link href="lib/font-awesome/css/solid.min.css" rel="stylesheet" />


</head>
<body>
    <h1><marquee>Welcome to the create student page</marquee></h1>
    <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="lib/moment/moment.min.js"></script>
    <script src="lib/dtpicker/js/tempusdominus-bootstrap-4.min.js"></script>
    <script language="javascript">
        $(document).ready(function () {
            $('#StudentsBirthdateCreate').datetimepicker({ format: 'YYYY-MM-DD' });
        });
    </script>

    <hr />
    <div class="offset-xl-0 col-xl-12"><nav class="navbar navbar-expand-sm navbar-light bg-light"><a style="color: red;" class="navbar-text" href="AdministratorHomePage.php.1">Administrator Homepage</a>&nbsp;|&nbsp;<a style="color: red;" class="navbar-text" href="ListStudentsAccount.php.1">List students' account</a>&nbsp;|&nbsp;<a style="color: red;" class="navbar-text" href="ListAdministratorsAccount.php.1">List administrators' account</a>&nbsp;|&nbsp;<a style="color: red;" class="navbar-text" href="ViewFeedback.php.1">View feedbacks</a>&nbsp;|&nbsp;<a style="color: red;" class="navbar-text" href="EditStudent.php.1">Edit student</a>&nbsp;|&nbsp;<a style="color: red;" class="navbar-text" href="DeleteUser.php.1">Delete user</a>&nbsp;|&nbsp;<a style="color: red;" class="navbar-text" href="CreateAdministrator.php.1">Create administrator</a>&nbsp;|&nbsp;<a style="color: red;" class="navbar-text" href="EditAdministrator.php.1">Edit administrator</a>&nbsp;|&nbsp;<a style="color: red;" class="navbar-text" href="Home.php.1">Logout</a></nav></div>
    <br />
    <div class="container">
        <form name="CreateStudentUserForm" method="post" action="">

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <h2>Create student account</h2>
                </div>
            </div>

            <div class="form-group row">
                <label for="studentID" class="control-label col-xl-3">Student ID: </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="studentID" name="StudentID" />
                </div>
            </div>

            <div class="form-group row">
                <label for="studentNRIC" class="control-label col-xl-3">Student NRIC: </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="studentNRIC" name="StudentNRIC" />
                </div>
            </div>

            <div class="form-group row">
                <label for="studentName" class="control-label col-xl-3">Student name: </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="studentName" name="StudentName" />
                </div>
            </div>

            <div class="form-group row">
                <label for="studentPassword" class="control-label col-xl-3">Student password: </label>
                <div class="col-xl-6">
                    <input type="password" class="form-control" id="studentPassword" name="StudentPassword" />
                </div>
            </div>

            <div class="form-group row">
                <label for="isItLocked" class="control-label col-xl-3">Is it locked (Y/N?): </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="isItLocked" name="IsItLocked" />
                </div>
            </div>

            <div class="form-group row">
                <label for="studentEmail" class="control-label col-xl-3">Student E-mail: </label>
                <div class="col-xl-6">
                    <input type="email" class="form-control" id="studentEmail" name="StudentEmail" />
                </div>
            </div>

            <div class="form-group row">
                <label for="studentBirthdate" class="control-label col-xl-3">Student date of birth: </label>
                <div class="col-xl-6">
                    <div class="input-group date" id="StudentsBirthdateCreate" data-target-input="nearest">
                        <input type="text" class="form-control" id="studentBirthdate" name="StudentBirthdate" />
                        <div class="input-group-append" data-target="#StudentsBirthdateCreate" data-toggle="datetimepicker">
                            <div class="input-group-text">
                                <i class="fas fa-calendar"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <input type="submit" class="btn btn-secondary" value="Create" />
                </div>
            </div>

        </form>
    </div>
    <br />
    <footer class="offset-xl-3"><marquee>@copy</marquee></footer>
</body>
</html>
