﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta />
    <title>Forget password</title>
    <!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/StyleSheet2.css" rel="stylesheet">


</head>
<body>
    <h1><marquee>Welcome to the forget password page</marquee></h1>
    <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <hr />
    <div class="offset-xl-3 col-xl-5">
        <nav class="navbar navbar-expand-sm navbar-light bg-light">
            <a style="color: red;" class="navbar-text" href="Home.php">Home</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="StudentLogin.php">Students Login</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="AdministratorLogin.php">Administrators Login</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="AboutUs.php">About Us</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="">Contact Us</a>
        </nav>
    </div>
    <br />
    <div class="container">
        <form name="" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <h2>Forget password</h2>
                </div>
            </div>

            <div class="form-group row">
                <label for="eMail" class="control-label col-xl-3">E-mail: </label>
                <div class="col-xl-6">
                    <input type="email" class="form-control" id="eMmail" name="EMail" />
                </div>
            </div>

            <div class="form-group row">
                <label for="newPassword" class="control-label col-xl-3">New password: </label>
                <div class="col-xl-6">
                    <input type="password" class="form-control" id="newPassword" name="NewPassword" />
                </div>
            </div>

            <div class="form-group row">
                <label for="confirmPassword" class="control-label col-xl-3">Re-type password: </label>
                <div class="col-xl-6">
                    <input type="password" class="form-control" id="confirmPassword" name="ConfirmPassword" />
                </div>
            </div>

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <input type="submit" class="btn btn-secondary" value="Submit" />
                </div>
            </div>
<?php
$servername = "localhost";
$user = "root";
$pass = "";
$dbname = "ViewProfile2";

$conn = mysqli_connect("localhost", "root", "", "ViewProfile2");

if (!$conn)
{
    die("Connection failed: ".mysqli_connect_error());
}

$email = htmlspecialchars(stripslashes(trim($_POST["EMail"])));
$password = htmlspecialchars(stripslashes($_POST["NewPassword"]));
$confirmpassword = htmlspecialchars(stripslashes($_POST["ConfirmPassword"]));
$select = "Select AdministratorID from Administrators Where AdministratorEmail = '$email'";

$output = mysqli_query($conn, $select);

if (mysqli_num_rows($output)>0)
{
    if ((empty($password) || empty($confirmpassword)) || ($password != $confirmpassword))
    {
        echo "The passwords are not the same or one or more of them is empty";
    }
    else
    {
        $insert = "UPDATE Administrators SET AdministratorPassword = password('$password') WHERE AdministratorEmail = '$email'";
        $r = mysqli_query($conn, $insert);

        if ($r)
        {
            echo "Password is updated";
        }
        else
        {
            echo "Error updating the password: ".mysqli_error($conn);
        }
    }
}
else
{
    $select2 = "select StudentID from Students where StudentEmail = '$email'";
    $res = mysqli_query($conn, $select2);

    if (mysqli_num_rows($res)>0)
    {
        if ((empty($password) || empty($confirmpassword)) || ($password != $confirmpassword))
        {
            echo "The passwords are not the same or one or more of them is empty";
        }
        else
        {
            $sql = "update Students set StudentPassword = password('$password') where StudentEmail = '$email'";
            $answer = mysqli_query($conn, $sql);

            if ($answer)
            {
                echo "Password is updated";
            }
            else
            {
                echo "Error updating the password: ".mysqli_error($conn);
            }
        }
    }
    else
    {
        echo "There is no such email address or your email address is empty";
    }
}

mysqli_close($conn);
?>

        </form>
    </div>
    <br />
    <footer class="offset-xl-3"><marquee>&copy</marquee></footer>
</body>
</html>
