﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta />
    <title>Create administrator</title>
    <!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/StyleSheet2.css" rel="stylesheet">
    <link href="lib/dtpicker/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link href="lib/font-awesome/css/fontawesome.min.css" rel="stylesheet" />
    <link href="lib/font-awesome/css/brands.min.css" rel="stylesheet" />
    <link href="lib/font-awesome/css/solid.min.css" rel="stylesheet" />


</head>
<body>
    <h1><marquee>Welcome to the create administrator page</marquee></h1>
    <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="lib/moment/moment.min.js"></script>
    <script src="lib/dtpicker/js/tempusdominus-bootstrap-4.min.js"></script>
    <script language="javascript">
        $(document).ready(function () {
            $('#AdministratorsBirthdateCreate').datetimepicker({ format: 'YYYY-MM-DD' });
        });
    </script>
    <hr />
    <div class="offset-xl-0 col-xl-12">
        <nav class="navbar navbar-expand-sm navbar-light bg-light">
            <a style="color: red;" class="navbar-text" href="AdministratorHomePage.php">Administrator Homepage</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ListStudentsAccount.php">List students' account</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ListAdministratorsAccount.php">List administrators' account</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="ViewFeedback.php">View feedbacks</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="CreateStudent.php">Create student</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="EditStudent.php">Edit student</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="DeleteUser.php">Delete user</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="EditAdministrator.php">Edit administrator</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="Lock.php">Lock</a>&nbsp;|&nbsp;
            <a style="color: red;" class="navbar-text" href="Home.php">Logout</a>
        </nav>
    </div>
    <br />

<?php
session_start();
$user = $_SESSION["name"];

echo "User ID: ".$user;
?>

    <br />
    <div class="container">
        <form name="CreateAdministratorUserForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <h2>Create administrator account</h2>
                </div>
            </div>

            <div class="form-group row">
                <label for="administratorID" class="control-label col-xl-3">Administrator ID: </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="administratorID" name="AdministratorID" />
                </div>
            </div>

            <div class="form-group row">
                <label for="administratorNRIC" class="control-label col-xl-3">Administrator NRIC: </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="administratorNRIC" name="AdministratorNRIC" />
                </div>
            </div>

            <div class="form-group row">
                <label for="administratorName" class="control-label col-xl-3">Administrator name: </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="administratorName" name="AdministratorName" />
                </div>
            </div>

            <div class="form-group row">
                <label for="administratorPassword" class="control-label col-xl-3">Administrator password: </label>
                <div class="col-xl-6">
                    <input type="password" class="form-control" id="administratorPassword" name="AdministratorPassword" />
                </div>
            </div>

            <!--<div class="form-group row">
                <label for="isItLocked" class="control-label col-xl-3">Is it locked (Y/N/y/n?): </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="isItLocked" name="IsItLocked" />
                </div>
            </div>-->

            <div class="form-group row">
                <label for="administratorEmail" class="control-label col-xl-3">Administrator E-mail: </label>
                <div class="col-xl-6">
                    <input type="email" class="form-control" id="administratorEmail" name="AdministratorEmail" />
                </div>
            </div>

            <!--<div class="form-group row">
                <label for="administratorBirthdate" class="control-label col-xl-3">Administrator date of birth (YYYY-MM-DD) / (YYYY-M-D): </label>
                <div class="col-xl-6">
                    <div class="input-group date" id="AdministratorsBirthdateCreate" data-target-input="nearest">
                        <input type="text" class="form-control" id="administratorBirthdate" name="AdministratorBirthdate" />
                        <div class="input-group-append" data-target="#AdministratorsBirthdateCreate" data-toggle="datetimepicker">
                            <div class="input-group-text">
                                <i class="fas fa-calendar"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>-->

            <div class="form-group row">
                <label for="birthYear" class="control-label col-xl-3">Administrator birthdate (YYYY): </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="birthYear" name="BirthYear" />
                </div>
            </div>

            <div class="form-group row">
                <label for="birthMonth" class="control-label col-xl-3">Administrator birthdate (MM/M): </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="birthMonth" name="BirthMonth" />
                </div>
            </div>

            <div class="form-group row">
                <label for="birthDay" class="control-label col-xl-3">Administrator birthdate (DD/D): </label>
                <div class="col-xl-6">
                    <input type="text" class="form-control" id="birthDay" name="BirthDay" />
                </div>
            </div>

            <div class="form-group row">
                <div class="offset-xl-3 col-xl-6">
                    <input type="submit" class="btn btn-secondary" value="Create" />
                </div>
            </div>

<?php
$conn = mysqli_connect("localhost", "root", "", "ViewProfile2");

if (!$conn)
{
    die("Connection failed: ".mysqli_connection_error());
}
else
{
}
$administratorID = htmlspecialchars(stripslashes(trim($_POST["AdministratorID"])));
$administratorname = htmlspecialchars(stripslashes(trim($_POST["AdministratorName"])));
$administratorNRIC = htmlspecialchars(stripslashes(trim($_POST["AdministratorNRIC"])));
$administratorpassword = htmlspecialchars(stripslashes($_POST["AdministratorPassword"]));
//$isitlocked = htmlspecialchars(stripslashes(trim($_POST["IsItLocked"])));
$administratoremail = htmlspecialchars(stripslashes(trim($_POST["AdministratorEmail"])));
/*$administratorbirthdate = htmlspecialchars(stripslashes(trim($_POST["AdministratorBirthdate"])));*/
$birthyear = htmlspecialchars(stripslashes(trim($_POST["BirthYear"])));
$birthmonth = htmlspecialchars(stripslashes(trim($_POST["BirthMonth"])));
$birthday = htmlspecialchars(stripslashes(trim($_POST["BirthDay"])));

if (empty($administratorID) || empty($administratorname) || empty($administratorNRIC) || empty($administratorpassword) || empty($administratoremail) || empty($birthyear) || empty($birthmonth) || empty($birthday))
{
    echo "All fields must not be empty";
}
else
{
    if (((int)$administratorID == $administratorID) && (strlen($administratorID) == 8) && ((int)$administratorID >= 20000000 && (int)$administratorID <= 29999999))
    {
        $select = "select AdministratorID from Administrators where AdministratorID = '$administratorID'";
        $result = mysqli_query($conn, $select);

        if (mysqli_num_rows($result)>0)
        {
            echo "There is already an administrator ID with the number";
        }
        else
        {
            $select = "select AdministratorID from Administrators where AdministratorNRIC = '$administratorNRIC'";
            $r = mysqli_query($conn, $select);

            if (mysqli_num_rows($r)==0 && strlen($administratorNRIC) == 9)
            {
                if ((int)$administratorname == 0)
                {
                    if (strlen($administratorpassword) < 8)
                    {
                        echo "The password's format is wrong";
                    }
                    else
                    {
                        if (!filter_var($administratoremail, FILTER_VALIDATE_EMAIL))
                        {
                            echo "Email is in a wrong format";
                        }
                        else
                        {
                            if (strlen($birthyear) == 4 && (int)$birthyear == $birthyear && (int)$birthyear >= 0 && (int)$birthyear <= 9999 && (int)$birthmonth >= 1 && (int)$birthmonth <= 12 && (int)$birthmonth == $birthmonth && (strlen($birthmonth) >= 1 && strlen($birthmonth) <= 2) &&
(
((int)$birthday >= 1 && (int)$birthday <= 28) || 
((int)$birthday >= 1 && (int)$birthday <= 29) || 
((int)$birthday >= 1 && (int)$birthday <= 30) || 
((int)$birthday >= 1 && (int)$birthday <= 31)
)
 && (int)$birthday == $birthday &&
(strlen($birthday) >= 1 && strlen($birthday) <= 2))
                            {
                                $birthdate = $birthyear."-".$birthmonth."-".$birthday;
                                $insert = "Insert into Administrators (AdministratorID, AdministratorNRIC, AdministratorName, AdministratorPassword, AdministratorEmail, IsItLocked, AdministratorDateOfBirth) values ('$administratorID', '$administratorNRIC', '$administratorname', password('$administratorpassword'), '$administratoremail', 'N', '$birthdate')";
                                $res = mysqli_query($conn, $insert);

                                if ($res)
                                {
                                    echo "Created successfully";
                                }
                                else
                                {
                                    echo "Error: ".$insert."<br>".mysqli_error($conn);
                                }
                            }
                            else
                            {
                                echo "The birthdate's format is wrong";
                            }
                        }
                    }
                }
                else
                {
                    echo "The name's format is wrong";
                }
            }
            else
            {
                echo "The NRIC already exists in the database or the format is wrong";
            }
        }
    }
    else
    {
        echo "The administrator ID is in a wrong format";
    }
}

mysqli_close($conn);
?>

        </form>
    </div>
    <br />
    <footer class="offset-xl-3"><marquee>&copy</marquee></footer>
</body>
</html>
